<template>
<div>
<v-container>
<h1>This is an about page</h1>
</v-container></div>
</template>
